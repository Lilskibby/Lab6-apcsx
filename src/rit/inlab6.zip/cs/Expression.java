package rit.cs;

public interface Expression {

    public int evaluate();

    public String emit();
}
